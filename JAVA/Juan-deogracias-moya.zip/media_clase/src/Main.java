//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        Scanner scanner = new Scanner(System.in);
        boolean error = false;

        int sumatorio = 0;
        int contador = 0;

        System.out.println("--INTRODUCE UN NUMERO EN PANTALLA--");
        while(error == false) {
            int numero = scanner.nextInt();
            if(numero != 0) {
                System.out.println("Perfecto procesando el datos correctamente. " +
                        "Ingrese uno nuevo");
                sumatorio += numero;
            }
            else{
                System.out.println("El numero ingresado es incorrecto. Finalizando el programa...");
                error = true;
            }
            contador++;
        }

        float resultado = sumatorio / (contador-1);
        System.out.println("--La media da como resultado " + resultado +"--");
        
        scanner.close();
    }
}